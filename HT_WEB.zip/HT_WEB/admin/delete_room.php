<?php
require('../admin/db_config.php');


$room_id = $_GET['id'];

// Delete room
// First delete from room_facilities
$facility_query = "DELETE FROM room_facilities WHERE room_id = ?";
$facility_stmt = $conn->prepare($facility_query);
$facility_stmt->bind_param("i", $room_id);
$facility_stmt->execute();

// Then delete from rooms
$query = "DELETE FROM Rooms WHERE room_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $room_id);

if ($stmt->execute()) {
    header("Location: rooms.php"); // Redirect back to listing
    exit();
} else {
    echo "<script>alert('Error deleting room');</script>";
}
?>