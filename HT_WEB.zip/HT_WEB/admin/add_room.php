<?php

require('../admin/db_config.php');


$facility_columns = [];
$facility_query = "SHOW COLUMNS FROM room_facilities";
$result = $conn->query($facility_query);
while ($col = $result->fetch_assoc()) {
    if ($col['Field'] !== 'room_id') {
        $facility_columns[] = $col['Field'];
    }
}


$image_name = '';
if (isset($_FILES['room_image']) && $_FILES['room_image']['error'] === 0) {
    $extension = pathinfo($_FILES['room_image']['name'], PATHINFO_EXTENSION);
   // $image_name = $room_id . '.' . $extension;
    $image_name = "room_" . time() . "_" . basename($_FILES['image']['name']);

    $image_path = "../images/rooms/" . $image_name;

    if (!move_uploaded_file($_FILES['room_image']['tmp_name'], $image_path)) {
        echo "<script>alert('Image upload failed');</script>";
        exit();
    }
}


if (isset($_POST['add_room'])) {
    $room_id = trim($_POST['room_number']);
    $room_type = trim($_POST['room_type']);
    $price = trim($_POST['price']);
    $availability = trim($_POST['status']);
    
    if (empty($room_id) || empty($room_type) || empty($price) || empty($availability)) {
        echo "<script>alert('All fields are required!');</script>";
        exit();
    }
    
    $availability_bool = ($availability === 'available') ? 1 : 0;

    $facilities = [];
    foreach ($facility_columns as $fac) {
        $facilities[$fac] = isset($_POST['facilities'][$fac]) ? 1 : 0;
    }

    $stmt = $conn->prepare("INSERT INTO Rooms (room_id, room_type, image_path, price, availability) VALUES (?, ?, ?, ?, ?)");
$stmt->bind_param("sssdi", $room_id, $room_type, $image_name, $price, $availability_bool);

    if (!$stmt->execute()) {
        echo "<script>alert('Error adding room');</script>";
        exit();
    }

    $facility_placeholders = implode(', ', array_keys($facilities));
    $facility_values = array_values($facilities);
    $sql = "INSERT INTO room_facilities (room_id, " . implode(', ', array_keys($facilities)) . ") VALUES (?" . str_repeat(", ?", count($facilities)) . ")";
    $stmt2 = $conn->prepare($sql);

    $types = 's' . str_repeat('i', count($facilities));
    $params = array_merge([ $room_id ], $facility_values);

    $stmt2->bind_param($types, ...$params);
    $stmt2->execute();

    if (isset($_FILES['room_image']) && $_FILES['room_image']['error'] === 0) {
        $image_name = $room_id . '_' . basename($_FILES['room_image']['name']);
        $image_path = "../images/rooms/" . $image_name;
        if (move_uploaded_file($_FILES['room_image']['tmp_name'], $image_path)) {
            $image_query = "INSERT INTO Images (room_id, image_path) VALUES (?, ?)";
            $image_stmt = $conn->prepare($image_query);
            $image_stmt->bind_param("ss", $room_id, $image_name);
            $image_stmt->execute();
        }
    }

    header("Location: rooms.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Room</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="styles.css">
   <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            width: 66.67%; /* 8 columns out of 12 */
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0,0,0,0.1);
        }
        h2 {
            text-align: center;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .btn-submit {
            width: auto;
            position: absolute;
            right: 20px;
            bottom: 20px;
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
        }
        .btn-submit:hover {
            background-color: #218838;
        }
    </style>
</head>
<body class = "bg-dark">
    <div class="container position-relative">
        <h2>Add Room with Facilities</h2>
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label>Room Number:</label>
                <input type="text" name="room_number" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Room Type:</label>
                <input type="text" name="room_type" class="form-control" required>
            </div>

            <div class="form-group">
                <label>Price:</label>
                <input type="number" name="price" class="form-control" step="0.01" required>
            </div>

            <div class="form-group">
                <label>Status:</label>
                <select name="status" class="form-control" required>
                    <option value="available">Available</option>
                    <option value="unavailable">Unavailable</option>
                </select>
            </div>

            <div class="form-group">
                <label>Facilities:</label><br>
                <?php foreach ($facility_columns as $facility): ?>
                    <input type="checkbox" name="facilities[<?php echo $facility; ?>]" value="1" id="<?php echo $facility; ?>">
                    <label for="<?php echo $facility; ?>"><?php echo ucfirst(str_replace('_', ' ', $facility)); ?></label><br>
                <?php endforeach; ?>
            </div>

            <div class="form-group">
                <label>Room Image:</label>
                <input type="file" name="room_image" class="form-control">
            </div>

            <button type="submit" name="add_room" class="btn-submit">Add Room</button>
        </form>
    </div>
</body>
</html>
