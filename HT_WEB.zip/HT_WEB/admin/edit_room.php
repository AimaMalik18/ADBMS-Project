<?php
require('../admin/db_config.php');

$room_id = $_GET['id'];

// Fetch room details
$query = "SELECT * FROM Rooms WHERE room_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $room_id);
$stmt->execute();
$result = $stmt->get_result();
$room = $result->fetch_assoc();

// Handle form submission
if (isset($_POST['update_room'])) {
    $room_type = $_POST['room_type'];
    $price = $_POST['price'];
    $availability = $_POST['availability'];
    $image_path = $room['image_path']; // Keep existing image by default

    // Check if a new image is uploaded
    if (!empty($_FILES['room_image']['name'])) {
        $target_dir = "../images/rooms/";
        $filename = basename($_FILES["room_image"]["name"]);
        $target_file = $target_dir . $filename;

        // Move the uploaded file
        if (move_uploaded_file($_FILES["room_image"]["tmp_name"], $target_file)) {
            $image_path = $filename;
        } else {
            echo "<script>alert('Error uploading image');</script>";
        }
    }

    // Update query including image_path
    $update_query = "UPDATE Rooms SET room_type = ?, price = ?, availability = ?, image_path = ? WHERE room_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param("sdisi", $room_type, $price, $availability, $image_path, $room_id);

    if ($update_stmt->execute()) {
        header("Location: rooms.php");
        exit();
    } else {
        echo "<script>alert('Error updating room');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit Room</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="styles.css">
</head>
<body class="bg-dark text-white">
    <div class="container mt-5">
        <h2 class="mb-4 text-center">Edit Room</h2>
        <div class="card bg-secondary p-4 mx-auto" style="max-width: 600px;">
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="room_number" class="form-label">Room Number</label>
                    <input type="text" class="form-control" value="<?php echo $room['room_id']; ?>" disabled>
                </div>

                <div class="mb-3">
                    <label for="room_type" class="form-label">Room Type</label>
                    <input type="text" name="room_type" class="form-control" value="<?php echo $room['room_type']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="price" class="form-label">Price</label>
                    <input type="number" step="0.01" name="price" class="form-control" value="<?php echo $room['price']; ?>" required>
                </div>

                <div class="mb-3">
                    <label for="availability" class="form-label">Availability</label>
                    <select name="availability" class="form-select" required>
                        <option value="1" <?php echo ($room['availability'] == 1) ? 'selected' : ''; ?>>Available</option>
                        <option value="0" <?php echo ($room['availability'] == 0) ? 'selected' : ''; ?>>Booked</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Current Image</label><br>
                    <img src="../images/rooms/<?php echo htmlspecialchars($room['image_path']); ?>" width="100%" style="max-height: 200px; object-fit: cover;" alt="Room Image">
                </div>

                <div class="mb-3">
                    <label for="room_image" class="form-label">Change Image</label>
                    <input type="file" name="room_image" class="form-control">
                </div>

                <div class="text-center">
                    <button type="submit" name="update_room" class="btn btn-warning">Update Room</button>
                    <a href="rooms.php" class="btn btn-light ms-2">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
