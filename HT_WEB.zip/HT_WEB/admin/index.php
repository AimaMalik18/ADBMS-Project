<?php
require('db_config.php');
if (isset($_POST['login'])) {
    $admin_name = $_POST['admin_name'];  // FIXED: name must match form input
    $admin_pass = $_POST['admin_pass'];  // FIXED: same here
    $role = $_POST['role'];

    $query = "SELECT * FROM users WHERE name = ? AND password = ? AND role = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sss", $admin_name, $admin_pass, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();

        $_SESSION['name'] = $row['name'];
        $_SESSION['role'] = $row['role'];
        $_SESSION['user_id'] = $row['user_id'];
        $_SESSION['user_email'] = $row['email'];

        // REDIRECT based on role
        if ($role === "admin") {
            header("Location: http://localhost:3000/admin/home.php");
        } elseif ($role === "user") {
            header("Location: http://localhost:3000/User/index.php");
        }
        exit();
    } else {
        echo "<script>alert('Invalid credentials. Please try again.');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&family=Underdog&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="style.css"/>
     <link rel="stylesheet" href="styles.css">
     <style>
        *{
            font-family: 'Roboto', sans-serif;
        }
        .h-font{
            font-family: 'Underdog', cursive;
        }
      /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button
         {
          -webkit-appearance: none;
          margin: 0;
         }
        .custom-bg{
            background-color:rgb(60, 89, 117) ; 
        }
        .custom-bg:hover{
            background-color:rgb(5, 56, 107) ;
        }
        .availability-form{
            margin-top: -50px;
            z-index: 2;
            position: relative;
        }
        .login-form{
            width: 400px;
            margin: auto;
            margin-top: 100px;
            padding: 20px;
            border-radius: 10px;
            background-color: rgb(60, 89, 117);
            box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
        }
    </style>
    <title>Admin Panel</title>
</head>
<body class = "bg-dark">
    <!-- header add kr lena rooms wali se required ka matlab hai ke isse khali nahi chor skte -->
        <div class = "login-form">
          <form method="POST">
    <h4 class="h-font" style="color:blanchedalmond;">Login Panel</h4>
    <div class="p-4">
        <div class="mb-3"> 
            <input name="admin_name" required type="text" class="form-control text-center" placeholder="Name">
        </div>
        <div class="mb-4"> 
            <input name="admin_pass" required type="password" class="form-control text-center" placeholder="Password">
        </div>  
        <div class="mb-4">
            <select name="role" required class="form-select text-center">
                <option value="">Select Role</option>
                <option value="admin">Admin</option>
                <option value="user">User</option>
            </select>
        </div>

        <button name="login" type="submit" class="btn text-white custom-bg w-100">LOGIN</button>

        <div class="text-center mt-3">
            <span style="color: blanchedalmond;">Don't have an account?</span>
            <br>
            <a href="http://localhost:3000/User/register.php" class="btn btn-outline-light mt-2">Register</a>
        </div>
    </div>
</form>

 
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
</body>
</html>