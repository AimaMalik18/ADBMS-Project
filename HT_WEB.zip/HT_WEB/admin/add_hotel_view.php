<?php
require('db_config.php');

if (isset($_POST['upload'])) {
    $view_name = $_POST['image_label'];
    $image = $_FILES['image']['name'];
    $image_tmp = $_FILES['image']['tmp_name'];

    $target_dir = "../images/hotel_images/";
    $target_path = $target_dir . basename($image);

    if (move_uploaded_file($image_tmp, $target_path)) {
        $stmt = $conn->prepare("INSERT INTO hotel_images (image_label, image_path) VALUES (?, ?)");
        $stmt->bind_param("ss", $view_name, $image);
        $stmt->execute();
        echo "<script>alert('View added successfully!');</script>";
    } else {
        echo "<script>alert('Image upload failed.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Add Hotel View</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="styles.css">

</head>
<body class="bg-dark text-light">
  <div class="container mt-5">
    <h2 class="text-center mb-4">Add Hotel View</h2>
    <div class="card p-4 bg-secondary" style="max-width: 600px; margin: auto;">
      <form method="POST" enctype="multipart/form-data">
        <div class="mb-3">
          <label class="form-label">View Name (e.g., Dining, Reception)</label>
          <input type="text" name="view_name" class="form-control" required>
        </div>
        <div class="mb-3">
          <label class="form-label">Upload Image</label>
          <input type="file" name="image" accept="image/*" class="form-control" required>
        </div>
        <div class="text-center">
          <button type="submit" name="upload" class="btn btn-warning">Upload</button>
          <a href="home.php" class="btn btn-light ms-2">Back</a>
        </div>
      </form>
    </div>
  </div>
</body>
</html>
