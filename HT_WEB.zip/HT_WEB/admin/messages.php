<?php
// Start the session at the VERY top


// Include database configuration
require('../admin/db_config.php');

// Debug: Print session values
//echo "<pre>";
//print_r($_SESSION);
//echo "</pre>";
/*
if (!isset($_SESSION['name']) || $_SESSION['role'] !== 'admin') {
    echo "<h3 style='color: red; text-align: center;'>Session not set properly! Please log in.</h3>";
    exit();
}*/


// Fetch messages from the database
$sql = "SELECT id, name, email_address, subject, message, created_at FROM messages ORDER BY created_at DESC";
$result = $conn->query($sql);

// Error handling for SQL query
if (!$result) {
    die("<h3 style='color: red;'>Database query failed: " . $conn->error . "</h3>");
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>User Messages - Royal Bliss Admin</title>
  <link rel="stylesheet" href="../style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
  <link rel="stylesheet" href="styles.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 1000px;
      margin: 50px auto;
      background-color: #fff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th, td {
      border: 1px solid #ddd;
      padding: 12px;
      text-align: center;
    }

    th {
      background-color: #3498db;
      color: white;
    }

    tr:nth-child(even) {
      background-color: #f9f9f9;
    }

    .btn {
      padding: 8px 14px;
      border: none;
      cursor: pointer;
      border-radius: 6px;
      background-color: #dc3545;
      color: #fff;
      font-weight: bold;
      transition: background-color 0.3s ease;
    }

    .btn:hover {
      background-color: #c82333;
    }
  </style>
</head>
<body class = "bg-dark">
  <div class="container">
    <h1>User Messages</h1>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Subject</th>
          <th>Message</th>
          <th>Created At</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($result->num_rows > 0): ?>
          <?php while($row = $result->fetch_assoc()): ?>
            <tr>
              <td><?php echo htmlspecialchars($row['id']); ?></td>
              <td><?php echo htmlspecialchars($row['name']); ?></td>
              <td><?php echo htmlspecialchars($row['email_address']); ?></td>
              <td><?php echo htmlspecialchars($row['subject']); ?></td>
              <td><?php echo nl2br(htmlspecialchars($row['message'])); ?></td>
              <td><?php echo htmlspecialchars($row['created_at']); ?></td>
            </tr>
          <?php endwhile; ?>
        <?php else: ?>
          <tr>
            <td colspan="6">No messages found.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

<script src="js/bootstrap.bundle.min.js" defer></script>
</body>
</html>
