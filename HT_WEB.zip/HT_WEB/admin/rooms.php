<?php

require('../admin/db_config.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to join rooms with room_facilities and get image_path
$query = "SELECT 
    r.room_id,
    r.room_type,
    r.image_path,
    r.price,
    r.availability,
    f.spa,
    f.wifi,
    f.air_conditioner,
    f.gym
FROM 
    rooms r
JOIN 
    room_facilities f ON r.room_id = f.room_id";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Rooms</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
  <style>
    body {
      padding: 40px;
    }
    .card-title {
      font-size: 1.2rem;
      font-weight: bold;
    }
    .card-text {
      font-size: 0.95rem;
    }
    .room-img {
      width: 100%;
      height: 200px;
      object-fit: cover;
      border-top-left-radius: 0.375rem;
      border-top-right-radius: 0.375rem;
    }
  </style>
</head>
<body class="bg-dark">
<div class="d-flex justify-content-between align-items-center mb-4">
  <h2 class="text-light mb-0">Available Rooms with Facilities</h2>
  <div class="ms-auto">
    <a href="add_room.php" class="btn btn-primary">Add New Room</a>
  </div>
</div>

<div class="row">
<?php while($room = mysqli_fetch_assoc($result)): ?>
<?php
    $image_path = "../images/rooms/" . htmlspecialchars($room['image_path']);
    if (!file_exists($image_path) || empty($room['image_path'])) {
        $image_path = "../images/rooms/default.jpg"; // fallback image
    }
?>
<div class="col-md-4">
  <div class="card mb-4 shadow-sm">
    <img src="<?= $image_path ?>" class="room-img" alt="<?= htmlspecialchars($room['room_type']) ?> Image">
    <div class="card-body">
      <h5 class="card-title">Room #<?= $room['room_id'] ?> - <?= htmlspecialchars($room['room_type']) ?></h5>
      <p class="card-text">Price: Rs <?= $room['price'] ?></p>
      <p class="card-text">Availability: <?= htmlspecialchars($room['availability']) ?></p>
      
      <p class="card-text"><strong>Facilities:</strong><br>
        <?php
          if ($room['spa']) echo "🛁 Spa<br>";
          if ($room['wifi']) echo "📶 WiFi<br>";
          if ($room['air_conditioner']) echo "❄️ Air Conditioner<br>";
          if ($room['gym']) echo "🏋️ Gym<br>";
        ?>
      </p>

      <div class="d-flex justify-content-between">
        <a href="edit_room.php?id=<?= $room['room_id'] ?>" class="btn btn-sm btn-warning">Edit</a>
        <a href="delete_room.php?id=<?= $room['room_id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this room?');">Delete</a>
      </div>
    </div>
  </div>
</div>
<?php endwhile; ?>
</div>

</body>
</html>
