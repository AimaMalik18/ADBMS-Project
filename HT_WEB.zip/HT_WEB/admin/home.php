
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Royal Bliss Admin Dashboard</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="styles.css">
  <style>
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color:rgb(1, 9, 20);
      margin: 0;
      padding: 0;
    }

    .admin-dashboard {
      max-width: 900px;
      margin: 50px auto;
      background-color: #ffffff;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
      position: relative;
    }

    h1 {
      text-align: center;
      color: #2c3e50;
      margin-bottom: 30px;
    }

    nav ul {
      display: flex;
      justify-content: space-around;
      padding: 0;
      list-style: none;
      background-color: #3498db;
      border-radius: 8px;
    }

    nav ul li a {
      display: block;
      padding: 14px 20px;
      text-decoration: none;
      color: white;
      font-weight: bold;
    }

    nav ul li a:hover {
      background-color: #2980b9;
      border-radius: 8px;
    }

    section {
      margin-top: 30px;
      text-align: center;
      font-size: 1.1rem;
      color: #555;
    }

    .logout-btn {
      position: absolute;
      top: 20px;
      right: 20px;
      background-color: #e74c3c;
      color: white;
      padding: 10px 18px;
      border: none;
      border-radius: 6px;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .logout-btn:hover {
      background-color: #c0392b;
    }
  </style>
</head>
<body>
  <div class="admin-dashboard">
    <button class="logout-btn" onclick="location.href='index.php'">Logout</button>
    <h1>Royal Bliss Admin Dashboard</h1>
    <nav>
      <ul>
        <li><a href="rooms.php">Room Management</a></li>
        <li><a href="messages.php">User Messages</a></li>
        <li><a href="add_hotel_view.php">Manage Hotel Views</a></li>
      </ul>
    </nav>
    <section>
      <p><i><b>Welcome, Admin! Select an option from the menu to manage content.</b></i></p>
    </section>
  </div>
</body>
</html>
