
<footer>
  <div class="container-fluid bg-light text-dark mt-5">
    <div class="row">
      <div class="col-lg-4 col-md-4 text-center p-4">
        <h5 class="h-font fw-bold">Royal Bliss</h5>
        <p>Welcome to Royal Bliss—where luxury meets comfort and every stay is a regal experience!</p>
      </div>
      <div class="col-lg-4 col-md-4 text-center p-4">
        <h5 class="h-font fw-bold">Contact Us</h5>
        <p>+92 234 567 890</p>
        <p>info@royalbliss.com</p>
        <p>Islamabad Shakar Parian, Pakistan</p>
      </div>
      <div class="col-lg-4 col-md-4 text-center p-4">
        <h5 class="h-font fw-bold">Follow Us</h5>
        <a href="#" class="d-inline-block mb-3">
          <span class="badge bg-light text-dark text-wrap fs-6 p-2"><i class="bi bi-twitter me-1"></i> Twitter</span>
        </a><br>
        <a href="#" class="d-inline-block mb-3">
          <span class="badge bg-light text-dark text-wrap fs-6 p-2"><i class="bi bi-facebook me-1"></i> Facebook</span>
        </a><br>
        <a href="#" class="d-inline-block mb-3">
          <span class="badge bg-light text-dark text-wrap fs-6 p-2"><i class="bi bi-instagram me-1"></i> Instagram</span>
        </a><br>
      </div>
    </div>
  </div>
  <div class="container-fluid bg-dark text-light text-center p-4 justify-content-evenly">
    <p class="h-font fs-4 m-0">Designed and Developed by Aima Malik, Ayesha Nadeem, Khadija Shafqat, Mahnoor Sajjad</p>
  </div>
</footer>