<?php
require('../admin/db_config.php');
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name     = trim($_POST['name']);
    $email    = trim($_POST['email']);
    $phone    = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm  = $_POST['confirm_password'];

    // Check if passwords match
    if ($password !== $confirm) {
        echo "<script>alert('Passwords do not match');</script>";
    } else {
        // Optional: Hash the password before storing (Recommended)
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);

        // Prepare insert query
        $query = "INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, 'user')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ssss", $name, $email, $hashed_password, $phone);

        if ($stmt->execute()) {
            echo "<script>alert('Registration successful!'); window.location.href='http://localhost:3000/User/index.php';</script>";
        } else {
            echo "<script>alert('Error: " . $stmt->error . "');</script>";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User Registration</title>

  <!-- Bootstrap CSS & Icons -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Underdog&display=swap" rel="stylesheet">

  <style>
    * {
      font-family: 'Roboto', sans-serif;
    }
    .h-font {
      font-family: 'Underdog', cursive;
    }
    body {
      background-color: #212529;
    }
    .registration-form {
      width: 700px;
      margin: auto;
      margin-top: 50px;
      padding: 30px;
      border-radius: 10px;
      background-color: rgb(60, 89, 117);
      box-shadow: 0px 0px 10px rgba(0,0,0,0.5);
      color: white;
    }
    .custom-bg {
      background-color: rgb(60, 89, 117);
    }
    .custom-bg:hover {
      background-color: rgb(5, 56, 107);
    }
    input[type="file"]::file-selector-button {
      background-color: #343a40;
      color: white;
      border: none;
      padding: 5px 10px;
      margin-right: 10px;
    }
  </style>
</head>
<body>

  <div class="registration-form">
    <form method="POST" action="register.php" enctype="multipart/form-data">
      <h4 class="h-font text-center mb-4">User Registration</h4>
      

        <div class="mb-3">
          <input type="text" name="name" class="form-control text-center" placeholder=" Name" required>
        </div>


      <div class="mb-3">
        <input type="email" name="email" class="form-control text-center" placeholder="Email" required>
      </div>
 <div class="mb-3">
        <input type="number" name="phone" class="form-control text-center" placeholder="Phone Number" required>
      </div>
 <div class="row">
        <div class="col-6 mb-3">
          <input type="password" name="password" class="form-control text-center" placeholder="Password" required>
        </div>
        <div class="col-6 mb-3">
          <input type="password" name="confirm_password" class="form-control text-center" placeholder="Confirm Password" required>
        </div>
      </div>
<div class="mb-3 text-center">
        <button type="submit" class="btn text-white custom-bg w-100">Register</button>
      </div>
    </form>
  </div>

  <!-- Bootstrap JS -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
