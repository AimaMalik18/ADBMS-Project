<?php
require('../admin/db_config.php');

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get data from POST form
    $name = $_POST['name'];
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO messages (name, email_address, subject, message) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $email, $subject, $message);

    if ($stmt->execute()) {
        echo "<script>alert('Message sent successfully!');</script>";
    } else {
        echo "<script>alert('Failed to send message.');</script>";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Underdog&display=swap" rel="stylesheet"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css"/>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
  <title>Hotel Management System</title>
  <style>
    * {
      font-family: 'Roboto', sans-serif;
    }
    .h-font {
      font-family: 'Underdog', cursive;
    }
    input::-webkit-outer-spin-button,
    input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .custom-bg {
      background-color: rgb(60, 89, 117);
    }
    .custom-bg:hover {
      background-color: rgb(5, 56, 107);
    }
    .availability-form {
      margin-top: -50px;
      z-index: 2;
      position: relative;
    }
  </style>
</head>
<body class="bg-dark">
  <?php include 'nav.php'; ?> <!-- ✅ Include your navbar here -->



<div class="my-5 px-4">
  <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font" style="color:blanchedalmond;">CONTACT US</h2>
  <hr class="bg-light">
</div>

<!-- Contact Form -->
<div class="container-fluid">
  <div class="row vh-100 d-flex align-items-center justify-content-center">
    <div class="col-lg-8">
      <div class="card p-4 shadow-lg">
        <h3 class="text-center mb-4 h-font bg-dark rounded" style="color:blanchedalmond;">Send a Message</h3>
    <form method="POST" action="">
  <div class="mb-3">
    <label class="form-label">Your Name</label>
    <input type="text" name="name" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Email Address</label>
    <input type="email" name="email" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Subject</label>
    <input type="text" name="subject" class="form-control" required>
  </div>
  <div class="mb-3">
    <label class="form-label">Message</label>
    <textarea name="message" class="form-control" rows="5" style="resize: none;" required></textarea>
  </div>
  <div class="text-center">
    <button type="submit" class="btn btn-dark w-100">Send</button>
  </div>
</form>

      </div>
    </div>
  </div>
</div>

 <?php include 'footer.php'; ?> <!-- ✅ Include your navbar here -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>  
