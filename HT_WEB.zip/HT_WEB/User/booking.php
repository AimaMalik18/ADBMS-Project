<?php
require('../admin/db_config.php');
session_start(); // Start session for user login

if (!isset($_GET['room_id']) || !is_numeric($_GET['room_id'])) {
    die("<div class='alert alert-danger text-center mt-5'>Invalid Room ID provided.</div>");
}

$room_id = intval($_GET['room_id']);

// Fetch room details
$stmt = $conn->prepare("SELECT * FROM rooms WHERE room_id = ?");
$stmt->bind_param("i", $room_id);
$stmt->execute();
$room = $stmt->get_result()->fetch_assoc();

if (!$room) {
    die("<div class='alert alert-danger text-center mt-5'>Room not found in database.</div>");
}

// Handle booking form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'] ?? 0;
    $checkin = $_POST['checkin'];
    $checkout = $_POST['checkout'];
    $payment_method = $_POST['payment_method']; // Get payment method

    if ($user_id == 0) {
        echo "<div class='alert alert-warning text-center'>Please <a href='rooms.php' class='alert-link'>login</a> to book a room.</div>";
    } elseif (empty($checkin) || empty($checkout)) {
        echo "<div class='alert alert-warning text-center'>Please select both check-in and check-out dates.</div>";
    } else {
        // Insert booking details
        $book = $conn->prepare("INSERT INTO bookings (user_id, room_id, checkin_date, checkout_date) VALUES (?, ?, ?, ?)");
        $book->bind_param("iiss", $user_id, $room_id, $checkin, $checkout);

        if ($book->execute()) {
            $new_booking_id = $book->insert_id; // Get the newly inserted booking ID
            $_SESSION['booking_id'] = $new_booking_id; // Store in session
            
            // Redirect to the selected payment page with booking ID
            header("Location: " . $payment_method . "?booking_id=" . $new_booking_id);
            exit;
        } else {
            echo "<div class='alert alert-danger text-center'>Booking Failed: " . $conn->error . "</div>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Book Room</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

  <?php include 'nav.php'; ?> <!-- ✅ Include your navbar here -->
</head>
<body class="bg-dark text-light">
<div class="container mt-5">
    <h2 class="text-center mb-4">Book Room #<?= $room_id ?> - <?= htmlspecialchars($room['room_type']) ?></h2>

    <div class="card p-4 shadow bg-light text-dark">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Check-in Date</label>
                <input type="date" name="checkin" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Check-out Date</label>
                <input type="date" name="checkout" class="form-control" required>
            </div>
            <div class="mb-3">
    <label class="form-label">Select Payment Method</label>
    <select class="form-select" name="payment_method" required>
        <option value="credit_payment.php">Debit Card</option>
    </select>
</div>

            <button type="submit" class="btn btn-success">Confirm Booking</button>
        </form>
    </div>
</div>
</body>
 <?php include 'footer.php'; ?> <!-- ✅ Include your navbar here -->
</html>
