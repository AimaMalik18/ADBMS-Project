


!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100..900;1,100..900&family=Underdog&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <link rel="stylesheet" href="style.css">
    <title>Hotel Management System</title>
    <style>
        *{
            font-family: 'Roboto', sans-serif;
        }
        .h-font{
            font-family: 'Underdog', cursive;
        }
      /* Chrome, Safari, Edge, Opera */
        input::-webkit-outer-spin-button,
        input::-webkit-inner-spin-button
         {
          -webkit-appearance: none;
          margin: 0;
         }
        .custom-bg{
            background-color:rgb(60, 89, 117) ; 
        }
        .custom-bg:hover{
            background-color:rgb(5, 56, 107) ;
        }
        .availability-form{
            margin-top: -50px;
            z-index: 2;
            position: relative;
        }
        .pop:hover{
            border-top-color: rgb(2, 133, 255) !important;
            transform: scale(1.03);
            transition: all 0.3s;
        }
    </style>
</head>
<body class = "bg-dark">

  <?php include 'nav.php'; ?> <!-- ✅ Include your navbar here -->

<!-- facilities hr tag se line atti hai or h-line(div) se hum uss line ko custumized kr skte hai width margin or height de kr -->
 <div class="my-5 px-4">
     <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font" style="color:blanchedalmond;">OUR FACILITIES</h2>
     <hr class="bg-light">
 </div>
 
 <p class="text-center mt-3 fs-3" style="color:blanchedalmond;">Explore our range of facilities designed for your comfort and convenience.</p>
 
 <div class="container">
     <div class="row">
         <div class="col-lg-6 col-md-6 mb-5 px-4">
             <div class="bg-light rounded p-4 border-5 border-top border-dark pop">
                 <div class="d-flex align-items-center mb-2">
                     <h4>📶</h4>
                     <h5 class="h-font fw-bold m-0 ms-3">Wi-Fi</h5>
                 </div>
                 <p>
                     Enjoy complimentary high-speed Wi-Fi throughout the hotel, keeping you connected during your stay.
                 </p>
             </div>
         </div>
         <div class="col-lg-6 col-md-6 mb-5 px-4">
             <div class="bg-light rounded p-4 border-5 border-top border-dark pop">
                 <div class="d-flex align-items-center mb-2">
                     <h4>❄️</h4>
                     <h5 class="h-font fw-bold m-0 ms-3">Air Conditioning</h5>
                 </div>
                 <p>
                        Experience ultimate comfort with our state-of-the-art air conditioning in every room. Get the perfect temperature for a restful night.
                 </p>
             </div>
         </div>
         
         
         <div class="col-lg-6 col-md-6 mb-5 px-4">
             <div class="bg-light rounded p-4 border-5 border-top border-dark pop">
                 <div class="d-flex align-items-center mb-2">
                     <h4>🛁</h4>
                     <h5 class="h-font fw-bold m-0 ms-3">Spa</h5>
                 </div>
                 <p>
                     Indulge in relaxation with our luxurious spa services, designed to rejuvenate your body and mind.
                 </p>
             </div>
         </div>
         <div class="col-lg-6 col-md-6 mb-5 px-4">
             <div class="bg-light rounded p-4 border-5 border-top border-dark pop">
                 <div class="d-flex align-items-center mb-2">
                     <h4>🏋️</h4>
                     <h5 class="h-font fw-bold m-0 ms-3">Gym</h5>
                 </div>
                 <p>
                    Stay fit and active with our fully equipped gym, available 24/7 for your convenience.
                 </p>
             </div>
         </div>
     </div>
 </div> <?php include 'footer.php'; ?> <!-- ✅ Include your navbar here -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>