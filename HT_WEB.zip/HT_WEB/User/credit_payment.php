<?php
session_start();
require('../admin/db_config.php');

$message = "";

// Retrieve booking ID from session or URL
$booking_id = $_GET['booking_id'] ?? $_SESSION['booking_id'] ?? null;

if (!$booking_id) {
    die("<div class='alert alert-danger text-center'>Error: Booking ID missing.</div>");
}

// Check if the booking ID exists before processing payment
$check_booking = $conn->prepare("SELECT room_id FROM bookings WHERE booking_id = ?");
$check_booking->bind_param("i", $booking_id);
$check_booking->execute();
$result = $check_booking->get_result();

if ($result->num_rows === 0) {
    die("<div class='alert alert-danger text-center'>Error: Booking does not exist.</div>");
}

$row = $result->fetch_assoc();
$room_id = $row['room_id']; // Fetch room ID for availability update

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $card_number = trim($_POST['card_number']);
    $expiry = trim($_POST['expiry']);
    $cvv = trim($_POST['cvv']);
    $amount = 100.00; // Replace with actual amount
    $payment_method = 'credit_card';
    $status = 'completed';

    // Insert payment details into database
    $insert_query = "INSERT INTO payments (booking_id, amount, payment_method, status) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($insert_query);
    $stmt->bind_param("idss", $booking_id, $amount, $payment_method, $status);

    if ($stmt->execute()) {
        // Update room availability to 0
        $update_room_query = "UPDATE rooms SET availability = 0 WHERE room_id = ?";
        $update_stmt = $conn->prepare($update_room_query);
        $update_stmt->bind_param("i", $room_id);
        $update_stmt->execute();

        $message = "Booking Done! Payment successful.";
    } else {
        $message = "Error processing payment!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Credit/Debit Card Payment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
  <?php include 'nav.php'; ?> <!-- ✅ Include your navbar here -->

</head>
<body class="bg-dark text-light">
    <div class="container my-5">
        <h2 class="text-center">Pay with Credit/Debit Card</h2>

        <?php if ($message): ?>
            <p class="text-center text-warning fw-bold"><?php echo $message; ?></p>
        <?php endif; ?>

        <form method="POST">
            <label for="card_number">Card Number:</label>
            <input type="text" class="form-control" name="card_number" required>
            <br>
            <label for="expiry">Expiry Date:</label>
            <input type="month" class="form-control" name="expiry" required>
            <br>
            <label for="cvv">CVV:</label>
            <input type="password" class="form-control" name="cvv" required>
            <br>
            <button type="submit" class="btn btn-primary">Pay Now</button>
        </form>
    </div>
</body>
 <?php include 'footer.php'; ?> <!-- ✅ Include your navbar here -->
</html>
