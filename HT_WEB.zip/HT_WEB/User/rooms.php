<?php

require('../admin/db_config.php');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$query = "SELECT 
    r.room_id,
    r.room_type,
    r.image_path,
    r.price,
    r.availability,
    f.spa,
    f.wifi,
    f.air_conditioner,
    f.gym
FROM 
    rooms r
JOIN 
    room_facilities f ON r.room_id = f.room_id
GROUP BY r.room_id";

$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Rooms</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@100..900&family=Underdog&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.min.css">

  <style>
    * {
        font-family: 'Roboto', sans-serif;
    }
    .h-font {
        font-family: 'Underdog', cursive;
    }
    body {
        padding: 40px;
    }
    .card-title {
        font-size: 1.2rem;
        font-weight: bold;
    }
    .card-text {
        font-size: 0.95rem;
    }
    .btnn {
        width: auto;
        position: absolute;
        right: 20px;
        bottom: 20px;
        background-color: #28a745;
        color: white;
        border: none;
        padding: 10px;
        cursor: pointer;
    }
    .room-img {
        width: 100%;
        height: 200px;
        object-fit: cover;
        border-radius: 8px;
    }
  </style>
</head>
<body class="bg-dark">
  <?php include 'nav.php'; ?> <!-- ✅ Include your navbar here -->

<div class="d-flex justify-content-center align-items-center mb-4">
    <h2 class="mt-5 pt-4 mb-4 text-center fw-bold h-font" style="color:blanchedalmond;">Available Rooms with Facilities</h2>
</div>

<div class="row">
<?php while($room = mysqli_fetch_assoc($result)): ?>
    <div class="col-md-4">
        <div class="card mb-4 shadow-sm">
            <!-- Corrected Image Path -->
            <?php 
       
$image_path = "../images/rooms/" . htmlspecialchars($room['image_path']);

// Optional: fallback if image file is missing
if (!file_exists($image_path) || empty($room['image_path'])) {
    $image_path = "../images/rooms/default.jpg"; // Make sure default.jpg exists
}
?>
<img src="<?= $image_path ?>" class="room-img" alt="<?= htmlspecialchars($room['room_type']) ?> Image">

            <div class="card-body">
                <h5 class="card-title">Room #<?= $room['room_id'] ?> - <?= htmlspecialchars($room['room_type']) ?></h5>
                <p class="card-text">Price: Rs <?= $room['price'] ?></p>
                <p class="card-text">Availability: <?= htmlspecialchars($room['availability']) ? 'Available' : 'Not Available' ?></p>

                <p class="card-text text-bold"><strong>Facilities:</strong><br>
                    <?php
                        if ($room['spa']) echo "🛁 Spa<br>";
                        if ($room['wifi']) echo "📶 WiFi<br>";
                        if ($room['air_conditioner']) echo "❄️ Air Conditioner<br>";
                        if ($room['gym']) echo "🏋️ Gym<br>";
                    ?>
                </p>

                <a href="booking.php?room_id=<?= $room['room_id'] ?>" class="btnn btn-sm rounded btn-outline-dark shadow-none">Book Now</a>
            </div>
        </div>
    </div>
<?php endwhile; ?>
</div>
 <?php include 'footer.php'; ?> <!-- ✅ Include your navbar here -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
